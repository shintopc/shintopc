# Design System Strategy: The Luminous Developer Identity

## 1. Overview & Creative North Star: "The Neon Observatory"
This design system is built for the elite developer ecosystem—a space where high-velocity coding meets editorial precision. Our Creative North Star is **"The Neon Observatory."** 

Unlike standard "dark mode" templates that feel heavy or muddy, this system treats the UI as a deep-space viewport. We break the rigid, boxy nature of traditional IDEs by utilizing **intentional asymmetry** and **luminous depth**. Elements don’t just sit on a grid; they float within a pressurized environment of charcoal and light. By overlapping glass containers and using aggressive typography scales, we move from "functional utility" to a "signature experience" that feels expensive, private, and powerful.

## 2. Colors: Depth Beyond the Void
The palette is anchored in a deep charcoal (`surface: #0e0e12`), but its soul lies in the tension between the `primary` (Electric Blue) and `secondary` (Vibrant Violet).

### The "No-Line" Rule
Sectioning must never be achieved through 1px solid borders. Boundaries are defined strictly by background shifts.
*   **The Technique:** A `surface-container-low` section sitting on a `surface` background creates a natural, soft-edge transition. 
*   **The Goal:** To eliminate visual "noise" and allow the content to breathe.

### Surface Hierarchy & Nesting
Treat the UI as a physical stack of semi-transparent materials.
*   **Nesting:** Place a `surface-container-highest` card inside a `surface-container` area to create a "lifted" focal point.
*   **The Glass & Gradient Rule:** For floating elements (Modals, Hover Cards), use `surface-variant` at 40% opacity with a `backdrop-blur` of 12px–20px. 
*   **Signature Textures:** Main CTAs should not be flat. Apply a subtle linear gradient from `primary` (#9da7ff) to `primary-dim` (#4e62ff) at a 135-degree angle to provide a "metallic sheen" look.

## 3. Typography: The Editorial Tech-Stack
We use **Inter** as our typographic backbone. To achieve a high-end feel, we rely on extreme contrast between `display` and `label` tiers.

*   **Display & Headlines:** Use `display-lg` (3.5rem) with negative letter-spacing (-0.02em) for hero moments. This creates an authoritative, "bold-tech" statement.
*   **Title & Body:** `title-md` (1.125rem) should be used for section headers to ensure they feel grounded. `body-md` (0.875rem) is the workhorse for code snippets and descriptions.
*   **Labels:** Use `label-sm` (0.6875rem) in All Caps with +0.05em letter-spacing for metadata and tags. This "micro-copy" approach adds a level of sophisticated detail found in premium watches and high-end hardware.

## 4. Elevation & Depth: Tonal Layering
We reject traditional drop shadows. We use light and opacity to define "up."

*   **The Layering Principle:** Stacking is the primary tool for hierarchy. A `surface-container-lowest` (#000000) drawer sliding over a `surface` background creates an immediate sense of "underneath."
*   **Ambient Shadows:** When an object must float (e.g., a floating action button), use an ultra-diffused shadow: `box-shadow: 0 20px 40px rgba(0, 0, 0, 0.4)`. The shadow should never be pure gray; it should feel like it's absorbing the surrounding charcoal.
*   **The "Ghost Border" Fallback:** If a container requires definition against a similar background, use `outline-variant` (#48474c) at **15% opacity**. This creates a "glint" on the edge of the glass rather than a hard line.
*   **Glassmorphism Depth:** To simulate high-end glass, add a top-inner-shadow (stroke) of `primary` at 10% opacity to simulate light hitting the top edge of a pane.

## 5. Components: Precision Primitives

### Buttons
*   **Primary:** Gradient-filled (`primary` to `primary-dim`), `round-md` (0.75rem), with a subtle `primary` outer glow on hover.
*   **Secondary:** `surface-container-high` background with a `Ghost Border`. Text color set to `on-surface`.
*   **Tertiary:** Ghost style. No background, `on-surface-variant` text, shifting to `primary` on hover.

### Glass Cards
*   **Rule:** Forbid divider lines.
*   **Separation:** Use `spacing-6` (1.5rem) to separate content blocks.
*   **Styling:** 40% opacity `surface-container-low`, 16px blur, and a 0.5px `outline-variant` border at 20% opacity.

### Input Fields
*   **Default:** `surface-container-lowest` background with a bottom-only `outline-variant` (20% opacity).
*   **Active:** The bottom border transitions to a 2px `primary` line. Helper text uses `label-sm`.

### Chips & Tags
*   **Developer Tags:** Use `secondary-container` (#5516be) for background with `on-secondary-container` (#d9c8ff) text. Keep corners `round-full`.

### Additional Component: The "Terminal Fragment"
A specialized container for code snippets using a `surface-container-lowest` background, `body-sm` typography, and a subtle vertical gradient on the left edge using `tertiary` (#81ecff) to signify "active code."

## 6. Do’s and Don’ts

### Do:
*   **Do** use asymmetrical layouts (e.g., a large display heading offset to the left with body text tucked into the right column).
*   **Do** use `tertiary` (#81ecff) sparingly as a "system status" or "success" highlight.
*   **Do** prioritize vertical rhythm using the `spacing-8` (2rem) and `spacing-12` (3rem) increments for major sections.

### Don't:
*   **Don't** use 100% white (#FFFFFF). Always use `on-surface` (#fcf8fe) to avoid "eye sear" on the dark background.
*   **Don't** use standard "Material" shadows. If it looks like a default shadow, it’s too heavy.
*   **Don't** use dividers. If two elements feel too close, increase the spacing token rather than adding a line.
*   **Don't** over-saturate. Let the deep charcoal do the heavy lifting; the electric blue and violet should be the "event," not the "background."