# Design System Specification

## 1. Overview & Creative North Star: "The Neon Monolith"

This design system is engineered for an elite developer audience that demands precision, depth, and a departure from the "boxed-in" web. The Creative North Star is **The Neon Monolith**: a philosophy that treats the UI as a series of high-density, illuminated data structures floating within a vast, dark void. 

We break the "template" look by rejecting rigid, symmetrical grids in favor of **intentional asymmetry** and **editorial pacing**. By utilizing generous whitespace (Scale 16 and 24) and overlapping 3D elements, we create a sense of architectural depth. This isn't just a dashboard; it’s a high-fidelity command center where light defines form, and shadows are never just black—they are absences of energy.

---

## 2. Colors & Surface Philosophy

The palette is rooted in the "void"—a combination of `surface_container_lowest` (#0E0E0E) and `surface` (#131313). 

### The "No-Line" Rule
Standard 1px solid borders for sectioning are strictly prohibited. Boundaries must be defined through:
*   **Tonal Shifts:** Transitioning from `surface` to `surface_container_low`.
*   **Luminous Glows:** Using `primary` (#D0BCFF) or `secondary` (#ADC6FF) with a 20px spread at 10% opacity to "lift" a component.

### Surface Hierarchy & Nesting
Treat the UI as physical layers of smoked glass. 
*   **Base:** `surface_dim` (#131313).
*   **Secondary Sections:** `surface_container_low` (#1C1B1B).
*   **Active Elements/Cards:** `surface_container_high` (#2A2A2A).
*   **Nesting:** When placing an element inside a container, use the next tier up (e.g., a `surface_container_highest` card inside a `surface_container_low` section) to create a soft, natural lift.

### The Glass & Gradient Rule
Floating elements (Modals, Popovers, Navigation) must use **Glassmorphism**. Apply `surface_variant` (#353534) at 40% opacity with a `backdrop-filter: blur(24px)`. Main CTAs should utilize a "Signature Texture": a linear gradient from `primary` (#D0BCFF) to `primary_container` (#A078FF) at a 135-degree angle to provide visual "soul."

---

## 3. Typography: Editorial Authority

We pair the technical precision of **Inter** with the aggressive, wide stance of **Space Grotesk** to create a high-contrast hierarchy.

*   **Display & Headlines (Space Grotesk):** These are your "Monoliths." Use `display-lg` for hero statements. The wide tracking and bold weights convey an elite, architectural feel.
*   **Body & Labels (Inter):** This is your "Data." It provides the legibility required for complex developer workflows. Use `body-md` for standard prose and `label-sm` for metadata.
*   **The Contrast Rule:** Always pair a `display-sm` headline with `label-md` uppercase sub-text to create a sophisticated, editorial tension.

---

## 4. Elevation & Depth

In this system, depth is a function of light, not lines.

*   **The Layering Principle:** Avoid box-shadows on every element. Reserve them for "Floating Command" items. Achieve hierarchy by stacking `surface_container` tiers.
*   **Ambient Shadows:** For floating glass panels, use extra-diffused shadows. 
    *   *Spec:* `0px 24px 48px rgba(0, 0, 0, 0.4), 0px 0px 1px rgba(255, 255, 255, 0.1)`.
*   **The "Ghost Border" Fallback:** If accessibility requires a container edge, use a Ghost Border: `outline_variant` (#494454) at 15% opacity. Never use 100% opaque borders.
*   **Interaction Glows:** Hover states on interactive cards should trigger a subtle `secondary_container` (#0566D9) outer glow to simulate an "energized" state.

---

## 5. Components

### Buttons
*   **Primary:** A gradient-fill (`primary` to `primary_container`) with a `full` roundedness. On hover, increase the spread of a `primary_fixed` shadow.
*   **Secondary:** A Ghost Border (`outline_variant` at 20%) with a blur backdrop. No solid background.
*   **Tertiary:** Text-only using `primary_fixed_dim`, shifting to `on_primary_fixed` on hover.

### Input Fields
*   **Style:** `surface_container_highest` background with a `sm` (0.125rem) roundedness. 
*   **Active State:** The bottom edge glows with a 1px `primary` line; no full-box stroke.
*   **Error:** Use `error` (#FFB4AB) for the label and a subtle `error_container` glow behind the input.

### Cards & Lists
*   **The Divider Rule:** Forbid the use of divider lines. Separate list items using `spacing-3` (1rem) of vertical white space or by alternating between `surface_container_low` and `surface_container_lowest`.
*   **3D Assets:** Hero cards should feature an overlapping 3D asset (PNG or Spline) that breaks the container's top boundary to emphasize the Z-axis.

### The Command Palette (Additional Component)
A heavy glassmorphism modal (Blur: 32px) centered on the screen. It uses `surface_container_highest` for the active selection row, creating a "spotlight" effect without borders.

---

## 6. Do’s and Don’ts

### Do
*   **Use Asymmetrical Grids:** Align text to the left but offset 3D assets or secondary data to the far right using `spacing-20`.
*   **Embrace the Void:** Use `spacing-24` (8.5rem) between major sections. Generous breathing room is the hallmark of premium design.
*   **Subtle Parallax:** Apply a slow (0.05 speed) parallax effect to background mesh gradients to create a sense of "living" space.

### Don’t
*   **Don't use pure white text:** Use `on_surface_variant` (#CBC3D7) for body text to reduce eye strain and maintain the dark-mode mood. Save `on_surface` (#E5E2E1) for headings.
*   **Don't use standard easing:** Use "Spring" physics for transitions (e.g., `stiffness: 100, damping: 20`). Standard CSS `ease-in-out` feels too "web-standard."
*   **Don't use high-contrast dividers:** If you feel the need to "separate," use a space, not a line. If the layout feels messy, your typography hierarchy is likely the issue, not a lack of borders.

---

## 7. Motion & Interaction

*   **Hover-Triggered Glows:** When a user hovers over a primary element, the accent color (`electric violet` or `cyber blue`) should bleed into the background slightly using a blurred radial gradient.
*   **Smooth Entry:** Elements should "float" into place from a `y: 20px` offset with an opacity fade, timed to `300ms` with a custom cubic-bezier (0.22, 1, 0.36, 1).